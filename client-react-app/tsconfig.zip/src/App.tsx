import React from 'react';
import { AuthProvider } from 'oidc-react';
import logo from './logo.svg';
import './App.css';
import LoggedIn from './LoggedIn';

const oidcConfig = {
  onSignIn: async (user: any) => {
    alert('You just signed in, congratz! Check out the console!');
    console.log(user);
    window.location.hash = '';
  },
  silent_redirect_uri: `http://localhost:3000/signin-callback`,
  post_logout_redirect_uri: `http://localhost:3000/`,
  response_type: 'code',
  authority: 'https://localhost:7210/',
  clientId: 'Localhost',
  clientSecret: '123456789',
  scope: 'openid profile email CedenteApi RealtimeApi GatewayAPI ServiceBusinessAPI UserAPIService EmailSuppotAPIService IdentityServerApi ServiceConsignadoAPI',
  redirectUri:'http://localhost:3000/signin-callback',
};

function App() {
  return (
    <AuthProvider {...oidcConfig}>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>OIDC React</p>
          <LoggedIn />
        </header>
      </div>
    </AuthProvider>
  );
}

export default App;
