# Example React OIDC Application

PS: Don't use `implicit`. Let Torsten Lodderstedt tell you [why you should stop using the OAuth implicit grant!](https://medium.com/oauth-2/why-you-should-stop-using-the-oauth-implicit-grant-2436ced1c926)
