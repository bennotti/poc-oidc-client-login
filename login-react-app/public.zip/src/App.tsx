import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import LoggedIn from './LoggedIn';

function App() {
  const searchParams = new URLSearchParams(document.location.search);
  const [usuario, setUsuario] = useState('empreendedor@finplace.com.br');
  const [senha, setSenha] = useState('F1npl@c3');
  const [codigoAutorizacao, setCodigoAutorizacao] = useState('');

  const carregarCodigoAutorizacao = async () => {
    const response = await fetch(`https://localhost:7210/api/auth/code?${searchParams.toString()}`).then((response) => response.json())
    setCodigoAutorizacao(response.data.codigoAutorizacao);
  };

  useEffect(() => {
    carregarCodigoAutorizacao().catch(console.log);
  }, [])

  const handleSubmit = async (event: any) => {
    event.preventDefault();

    const response = await fetch('https://localhost:7210/api/auth/login', {  // Enter your IP address here
      method: 'POST', 
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        codigoAutorizacao,
        senha,
        login: usuario,
      }) // body data type must match "Content-Type" header
    }).then((response) => response.json())
    window.location.href = response.data.redirectUri;
    // console.log(response);
  }

  const handleChangeUsuario = (event: any) => {
    setUsuario(event.target.value);
  }

  const handleChangeSenha = (event: any) => {
    setSenha(event.target.value);
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>Login</h1>
        <div>
        <form onSubmit={handleSubmit}>
          <label>
            Usuario:
            <input value={usuario} onChange={handleChangeUsuario} />
          </label>
          <label>
            Senha:
            <input value={senha} onChange={handleChangeSenha} />
          </label>
          <input type="submit" value="Submit" disabled={codigoAutorizacao === ''}/>
        </form>
        </div>
        <p>{codigoAutorizacao}</p>
        <p>{searchParams.get('client_id')}</p>
        <p>{searchParams.get('redirect_uri')}</p>
        <p>{searchParams.get('response_type')}</p>
        <p>{searchParams.get('scope')}</p>
        <p>{searchParams.get('state')}</p>
        <p>{searchParams.get('code_challenge')}</p>
        <p>{searchParams.get('code_challenge_method')}</p>
        <p>{searchParams.get('response_mode')}</p>
      </header>
    </div>
  );
}

export default App;
